/* ================================================================
   PORTFOLIO JAVASCRIPT
   File: js/main.js

   This file handles:
   1. Sticky navigation bar
   2. Mobile menu toggle
   3. Scroll-triggered fade-in animations
   4. Skill bar animations
   5. "Read More" project toggles
   6. Back-to-top button
   7. Contact form feedback
   8. Active nav link highlighting
   9. Footer year auto-update

   You generally don't need to edit this file unless you want to
   change animation timing or add new interactive features.
================================================================ */

/* ================================================================
   1. NAVBAR — becomes opaque when user scrolls down
================================================================ */
const navbar = document.getElementById('navbar');

function handleNavScroll() {
  if (window.scrollY > 40) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
}

window.addEventListener('scroll', handleNavScroll, { passive: true });
handleNavScroll(); // Run once on page load


/* ================================================================
   2. MOBILE MENU TOGGLE
================================================================ */
const navToggle = document.getElementById('navToggle');
const navLinks  = document.getElementById('navLinks');

navToggle.addEventListener('click', () => {
  const isOpen = navLinks.classList.toggle('open');
  navToggle.classList.toggle('open');
  navToggle.setAttribute('aria-expanded', isOpen);
  // Prevent body scroll when menu is open
  document.body.style.overflow = isOpen ? 'hidden' : '';
});

// Close menu when a link is clicked
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    navToggle.classList.remove('open');
    navToggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  });
});


/* ================================================================
   3. FADE-IN ANIMATIONS ON SCROLL
   Elements with class "fade-in" become visible when they enter
   the viewport. The Intersection Observer API handles this
   efficiently without any janky scroll event listeners.
================================================================ */
const fadeObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // Stop observing once visible (one-time animation)
        fadeObserver.unobserve(entry.target);
      }
    });
  },
  {
    threshold: 0.12,       // Trigger when 12% of element is visible
    rootMargin: '0px 0px -40px 0px'  // Slightly early trigger
  }
);

// Observe all elements with the fade-in class
document.querySelectorAll('.fade-in').forEach(el => {
  fadeObserver.observe(el);
});


/* ================================================================
   4. SKILL BAR ANIMATIONS
   When skill bars scroll into view, they animate from 0% to their
   target width (set by data-level attribute in the HTML).
================================================================ */
const skillObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const fills = entry.target.querySelectorAll('.skill-fill');
        fills.forEach(fill => {
          const level = fill.getAttribute('data-level') || 0;
          // Small delay so the animation starts after fade-in
          setTimeout(() => {
            fill.style.width = level + '%';
          }, 300);
        });
        skillObserver.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.2 }
);

document.querySelectorAll('.skill-category').forEach(el => {
  skillObserver.observe(el);
});


/* ================================================================
   5. PROJECT "READ MORE" TOGGLES
   Expands hidden project detail sections when button is clicked.
================================================================ */
document.querySelectorAll('.project-expand-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const targetId = btn.getAttribute('aria-controls');
    const detail   = document.getElementById(targetId);

    if (!detail) return;

    const isExpanded = btn.getAttribute('aria-expanded') === 'true';

    if (isExpanded) {
      // Collapse
      detail.hidden = true;
      btn.setAttribute('aria-expanded', 'false');
      btn.innerHTML = 'Read More <i class="ph ph-caret-down" aria-hidden="true"></i>';
    } else {
      // Expand
      detail.hidden = false;
      btn.setAttribute('aria-expanded', 'true');
      btn.innerHTML = 'Read Less <i class="ph ph-caret-up" aria-hidden="true"></i>';
    }
  });
});


/* ================================================================
   6. BACK-TO-TOP BUTTON
   Appears after the user scrolls down 400px.
================================================================ */
const backToTop = document.getElementById('backToTop');

function handleBackToTop() {
  if (window.scrollY > 400) {
    backToTop.hidden = false;
  } else {
    backToTop.hidden = true;
  }
}

window.addEventListener('scroll', handleBackToTop, { passive: true });

backToTop.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});


/* ================================================================
   7. CONTACT FORM FEEDBACK
   Shows a success or error message after submission.
   If you're using Formspree, this handles the AJAX response.
================================================================ */
const contactForm = document.getElementById('contactForm');
const formStatus  = document.getElementById('form-status');

if (contactForm) {
  contactForm.addEventListener('submit', async (e) => {
    // Only intercept if a real Formspree URL is set
    const action = contactForm.getAttribute('action');
    if (!action || action.includes('YOUR_FORM_ID')) {
      // No Formspree set up yet — show a friendly notice
      e.preventDefault();
      showFormStatus('To activate this form, sign up at formspree.io and replace YOUR_FORM_ID in index.html.', 'error');
      return;
    }

    // Formspree AJAX submission
    e.preventDefault();
    const data = new FormData(contactForm);

    try {
      const res = await fetch(action, {
        method: 'POST',
        body: data,
        headers: { 'Accept': 'application/json' }
      });

      if (res.ok) {
        showFormStatus('✓ Message sent! I\'ll be in touch soon.', 'success');
        contactForm.reset();
      } else {
        showFormStatus('Something went wrong. Please email me directly.', 'error');
      }
    } catch {
      showFormStatus('Network error. Please try again or email me directly.', 'error');
    }
  });
}

function showFormStatus(message, type) {
  formStatus.textContent = message;
  formStatus.className   = 'form-status ' + type;
  formStatus.hidden = false;
  // Auto-hide after 6 seconds
  setTimeout(() => { formStatus.hidden = true; }, 6000);
}


/* ================================================================
   8. ACTIVE NAV LINK — highlights current section in nav
   Uses IntersectionObserver to track which section is visible.
================================================================ */
const sections = document.querySelectorAll('section[id]');
const allNavLinks = document.querySelectorAll('.nav-links a');

const navObserver = new IntersectionObserver(
  (entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const id = entry.target.getAttribute('id');
        allNavLinks.forEach(link => {
          link.classList.remove('active');
          if (link.getAttribute('href') === '#' + id) {
            link.classList.add('active');
          }
        });
      }
    });
  },
  {
    rootMargin: '-40% 0px -55% 0px'
  }
);

sections.forEach(section => navObserver.observe(section));


/* ================================================================
   9. FOOTER YEAR — auto-updates every new year
================================================================ */
const yearEl = document.getElementById('footer-year');
if (yearEl) {
  yearEl.textContent = new Date().getFullYear();
}


/* ================================================================
   SMOOTH SCROLL OFFSET — accounts for fixed navbar height
   Prevents headings from hiding behind the sticky nav.
================================================================ */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (!target) return;

    e.preventDefault();
    const navHeight = navbar ? navbar.offsetHeight : 72;
    const offset = target.getBoundingClientRect().top + window.scrollY - navHeight - 16;

    window.scrollTo({ top: offset, behavior: 'smooth' });
  });
});

# 🌿 Personal Portfolio Website

A modern, minimal, warm personal portfolio — built with plain HTML, CSS, and JavaScript.
No complicated frameworks. No build tools. Just open the files and edit.

---

## 📁 File Structure

```
portfolio/
├── index.html          ← THE MAIN FILE — edit your content here
├── css/
│   └── style.css       ← All visual styles and colors
├── js/
│   └── main.js         ← Animations and interactive features
├── images/
│   └── headshot.jpg    ← Replace with your own photo
├── assets/
│   └── resume.pdf      ← Replace with your own résumé PDF
└── README.md           ← This file
```

---

## ✏️ How to Edit Your Content

### Changing Text
Open `index.html` in any text editor (Notepad, TextEdit, or VS Code).

Each section is clearly labeled with a comment like this:
```html
<!-- ============================================================
  SECTION 1: WELCOME / HERO
  Edit: your name, headline, and mission statement
============================================================ -->
```

Search for the comment header for the section you want to change, then edit the text between the HTML tags.

**Common edits:**
| What to change | Search for in index.html |
|---|---|
| Your name (hero) | `Your Full Name` |
| Your headline | `Student Affairs &amp; Human Resources Professional` |
| Your mission statement | `hero-mission` |
| Your email | `your.email@example.com` |
| Your LinkedIn URL | `linkedin.com/in/yourprofile` |
| Your GitHub URL | `github.com/yourusername` |
| Footer name | Inside `<footer>` |

---

## 🖼️ How to Replace Your Photo

1. Get a professional headshot photo (square or portrait orientation works best)
2. Rename your photo file to `headshot.jpg`
3. Copy it into the `images/` folder, replacing the placeholder
4. Open your site — your photo will appear automatically

**Tips:**
- Keep file size under 500KB for fast loading (use [squoosh.app](https://squoosh.app) to compress)
- A 400×500px photo or larger looks sharp on all screens
- Always update the `alt` text to describe yourself:
  ```html
  alt="Professional headshot of Your Name smiling"
  ```

---

## 🎨 How to Change Colors

Open `css/style.css`. At the very top you'll see the **Design Tokens** section:

```css
:root {
  --color-bg:          #FAF9F6;   /* page background */
  --color-accent:      #6B7F6E;   /* sage green — main accent */
  --color-text:        #2C2825;   /* primary text */
  /* ... more colors ... */
}
```

Change any hex value (`#6B7F6E`) to any color you like.
The entire site updates instantly.

**Suggested accent colors:**
| Color | Hex |
|---|---|
| Sage green (default) | `#6B7F6E` |
| Dusty rose | `#B07B82` |
| Warm navy | `#3D4F6B` |
| Terracotta | `#B5714F` |
| Slate blue | `#5C6E8A` |

Use a free tool like [coolors.co](https://coolors.co) to find colors you love.

---

## 📄 How to Update Your Résumé

1. Export your résumé as a PDF
2. Rename it `resume.pdf`
3. Copy it into the `assets/` folder, replacing the old one
4. The download button in the Résumé section will now serve your new PDF

**To enable the PDF preview** (shows your résumé inline on the page):

Find this comment in `index.html`:
```html
<!-- OPTIONAL RESUME PREVIEW — remove the comment tags to enable
<div class="resume-preview">
  <iframe ...
```
Delete the `<!--` and `-->` tags around the `<iframe>` block.

---

## 💼 How to Add a New Experience

Find the Experience section in `index.html` (search for `SECTION 3: EXPERIENCE`).

Copy this entire block:
```html
<div class="timeline-item fade-in">
  <div class="timeline-dot" aria-hidden="true"></div>
  <div class="timeline-card">
    <div class="timeline-meta">
      <span class="timeline-date">2022 – Present</span>
      <span class="timeline-tag">Leadership</span>
    </div>
    <h3 class="timeline-role">Your Job Title</h3>
    <p class="timeline-org">Organization Name · City, ST</p>
    <ul class="timeline-bullets">
      <li>Your first bullet point here.</li>
      <li>Your second bullet point here.</li>
    </ul>
  </div>
</div>
```

Paste it inside `<div class="timeline">` and edit the text.

---

## 🗂️ How to Add a New Project

Find the Projects section (search for `SECTION 5: PROJECTS`).

Copy this block:
```html
<div class="project-card fade-in delay-1">
  <div class="project-icon" aria-hidden="true">
    <i class="ph ph-presentation-chart"></i>
  </div>
  <div class="project-content">
    <div class="project-tags">
      <span class="tag">Category</span>
      <span class="tag">Year</span>
    </div>
    <h3>Project Title</h3>
    <p>Short description of the project.</p>
    <button class="project-expand-btn" aria-expanded="false" aria-controls="project-detail-NEW">
      Read More <i class="ph ph-caret-down" aria-hidden="true"></i>
    </button>
    <div class="project-detail" id="project-detail-NEW" hidden>
      <p>Longer description shown when expanded.</p>
    </div>
  </div>
</div>
```

**Important:** Change `project-detail-NEW` to a unique ID like `project-detail-5` for each new card.

**Icon options** — replace `ph-presentation-chart` with any icon from [phosphoricons.com](https://phosphoricons.com/):
- `ph-clipboard-text` — assessment/documents
- `ph-users-three` — team/people
- `ph-sparkle` — development/growth
- `ph-globe-hemisphere-west` — global/DEI work
- `ph-megaphone` — advocacy/presentation
- `ph-lightbulb` — ideas/innovation

---

## 📬 How to Activate the Contact Form

The contact form uses [Formspree](https://formspree.io) — it's free and requires no server.

1. Go to [formspree.io](https://formspree.io) and create a free account
2. Create a new form and copy your **Form ID** (looks like `xvoeknxy`)
3. In `index.html`, find the `<form>` tag and replace `YOUR_FORM_ID`:
   ```html
   action="https://formspree.io/f/YOUR_FORM_ID"
   ```
   becomes:
   ```html
   action="https://formspree.io/f/xvoeknxy"
   ```
4. Save and push to GitHub — the form is now live!

---

## 🚀 How to Deploy to GitHub Pages (Step-by-Step)

GitHub Pages hosts your site for **free** at `https://yourusername.github.io/portfolio`

### First-time setup:

**Step 1:** Create a free account at [github.com](https://github.com) if you don't have one.

**Step 2:** Create a new repository:
- Click the `+` button → **New repository**
- Name it `portfolio` (or anything you like)
- Set it to **Public**
- Click **Create repository**

**Step 3:** Upload your files:
- Click **uploading an existing file** on the repository page
- Drag and drop ALL your portfolio files (index.html, the css/ folder, js/ folder, images/ folder, assets/ folder)
- Click **Commit changes**

**Step 4:** Turn on GitHub Pages:
- Go to your repository → **Settings** tab
- Click **Pages** in the left sidebar
- Under **Source**, select **Deploy from a branch**
- Choose branch: `main` and folder: `/ (root)`
- Click **Save**

**Step 5:** Wait 1–2 minutes, then visit:
`https://yourusername.github.io/portfolio`

🎉 Your site is live!

---

## 🔄 How to Update Your Site After Changes

After editing files on your computer:

1. Go to your GitHub repository in the browser
2. Navigate to the file you changed (e.g., `index.html`)
3. Click the **pencil icon** (Edit this file)
4. Paste your updated content
5. Click **Commit changes**
6. Your site updates automatically within 1–2 minutes

**OR** if you use GitHub Desktop (recommended for frequent updates):
1. Make changes to files on your computer
2. Open GitHub Desktop → you'll see your changes listed
3. Write a short description (e.g., "Update experience section")
4. Click **Commit to main**
5. Click **Push origin**

---

## 🎨 How to Change Your Fonts

Fonts are loaded in the `<head>` section of `index.html`:
```html
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond...
```

1. Browse [fonts.google.com](https://fonts.google.com) and pick two fonts
2. Click **Get font** → **Get embed code** → copy the `<link>` tag
3. Replace the existing font link in `index.html`
4. In `css/style.css`, update the `:root` section:
   ```css
   --font-display: 'Your New Display Font', serif;
   --font-body:    'Your New Body Font', sans-serif;
   ```

---

## ♿ Accessibility Notes

This site is built with accessibility in mind:
- All images have `alt` text — **keep these updated** when you add photos
- Color contrast meets WCAG AA standards with the default palette
- Navigation works with keyboard (Tab key + Enter)
- Form labels are properly associated with inputs
- Animated elements respect `prefers-reduced-motion` (set by OS accessibility settings)
- ARIA labels on icons and interactive elements

---

## 📌 Quick Reference: Most-Edited Files

| Task | File to edit |
|---|---|
| Change name, text, content | `index.html` |
| Change colors, fonts, spacing | `css/style.css` |
| Add/change animations | `js/main.js` |
| Replace headshot | `images/headshot.jpg` |
| Replace résumé | `assets/resume.pdf` |

---

*Built with HTML, CSS, and JavaScript. Hosted on GitHub Pages.*
